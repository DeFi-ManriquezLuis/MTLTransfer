<?php
class linguaSiteTmplvarContentvalues extends xPDOSimpleObject {}