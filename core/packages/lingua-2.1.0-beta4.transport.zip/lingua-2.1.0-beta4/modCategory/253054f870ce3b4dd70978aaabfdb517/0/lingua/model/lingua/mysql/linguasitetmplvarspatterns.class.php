<?php
require_once (dirname(dirname(__FILE__)) . '/linguasitetmplvarspatterns.class.php');
class linguaSiteTmplvarsPatterns_mysql extends linguaSiteTmplvarsPatterns {}