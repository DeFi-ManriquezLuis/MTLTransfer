<?php
require_once (dirname(dirname(__FILE__)) . '/linguaresourcescopes.class.php');
class linguaResourceScopes_mysql extends linguaResourceScopes {}