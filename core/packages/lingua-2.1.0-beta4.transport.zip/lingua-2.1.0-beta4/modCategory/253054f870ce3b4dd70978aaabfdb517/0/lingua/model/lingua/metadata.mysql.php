<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'linguaLangs',
    1 => 'linguaResourceScopes',
    2 => 'linguaSiteContent',
    3 => 'linguaSiteTmplvarContentvalues',
    4 => 'linguaSiteTmplvars',
    5 => 'linguaSiteTmplvarsPatterns',
  ),
);