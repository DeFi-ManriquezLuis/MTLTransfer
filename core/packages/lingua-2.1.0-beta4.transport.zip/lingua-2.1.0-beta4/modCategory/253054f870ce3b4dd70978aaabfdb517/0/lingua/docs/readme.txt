-----------------------
Package: Lingua
-----------------------
author:
goldsky <goldsky@virtudraft.com>

collaborators:
Adam Wintle <adam@monogon.co>

Lingua is a multi-lingual plugin system for MODX Revolution.

References:
1. http://en.wikipedia.org/wiki/ISO_639-1_language_matrix
2. http://www.science.co.il/language/locale-codes.asp
3. http://www.php.net/manual/en/book.intl.php