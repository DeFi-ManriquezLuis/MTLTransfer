<?php
class linguaResourceScopes extends xPDOSimpleObject {}