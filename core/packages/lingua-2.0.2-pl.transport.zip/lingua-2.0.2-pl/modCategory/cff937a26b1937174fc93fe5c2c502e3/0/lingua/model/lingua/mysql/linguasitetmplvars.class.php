<?php
require_once (dirname(dirname(__FILE__)) . '/linguasitetmplvars.class.php');
class linguaSiteTmplvars_mysql extends linguaSiteTmplvars {}