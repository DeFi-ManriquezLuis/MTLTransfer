<?php
require_once (dirname(dirname(__FILE__)) . '/linguasitecontent.class.php');
class linguaSiteContent_mysql extends linguaSiteContent {}