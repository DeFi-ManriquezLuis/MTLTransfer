<?php
class smarttagTags extends xPDOSimpleObject {}