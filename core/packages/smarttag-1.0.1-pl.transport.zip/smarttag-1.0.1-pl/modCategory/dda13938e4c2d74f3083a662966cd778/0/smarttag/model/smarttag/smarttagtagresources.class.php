<?php
class smarttagTagresources extends xPDOObject {}