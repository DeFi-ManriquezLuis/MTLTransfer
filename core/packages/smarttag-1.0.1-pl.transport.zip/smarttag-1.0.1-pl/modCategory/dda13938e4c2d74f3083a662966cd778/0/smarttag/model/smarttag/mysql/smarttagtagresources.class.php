<?php
require_once (dirname(dirname(__FILE__)) . '/smarttagtagresources.class.php');
class smarttagTagresources_mysql extends smarttagTagresources {}