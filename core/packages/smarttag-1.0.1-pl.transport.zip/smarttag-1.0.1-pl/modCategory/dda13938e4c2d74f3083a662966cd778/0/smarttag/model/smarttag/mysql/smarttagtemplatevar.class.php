<?php
require_once (dirname(dirname(__FILE__)) . '/smarttagtemplatevar.class.php');
class smarttagTemplateVar_mysql extends smarttagTemplateVar {}