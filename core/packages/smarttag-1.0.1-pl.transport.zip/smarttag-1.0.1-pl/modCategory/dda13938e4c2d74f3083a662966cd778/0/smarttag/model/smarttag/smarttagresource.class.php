<?php
class smarttagResource extends modResource {}