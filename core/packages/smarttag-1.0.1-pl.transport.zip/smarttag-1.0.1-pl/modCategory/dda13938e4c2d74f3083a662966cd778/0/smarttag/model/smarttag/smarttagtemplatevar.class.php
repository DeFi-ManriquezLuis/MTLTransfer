<?php
class smarttagTemplateVar extends modTemplateVar {}