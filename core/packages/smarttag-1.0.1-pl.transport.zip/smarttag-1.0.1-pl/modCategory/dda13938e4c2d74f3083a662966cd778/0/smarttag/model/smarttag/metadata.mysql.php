<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'smarttagTagresources',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'smarttagTags',
  ),
  'modTemplateVar' => 
  array (
    0 => 'smarttagTemplateVar',
  ),
  'modResource' => 
  array (
    0 => 'smarttagResource',
  ),
);