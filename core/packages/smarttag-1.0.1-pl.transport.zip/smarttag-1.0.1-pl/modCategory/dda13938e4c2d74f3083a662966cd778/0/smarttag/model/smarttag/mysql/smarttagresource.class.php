<?php
require_once (dirname(dirname(__FILE__)) . '/smarttagresource.class.php');
class smarttagResource_mysql extends smarttagResource {}