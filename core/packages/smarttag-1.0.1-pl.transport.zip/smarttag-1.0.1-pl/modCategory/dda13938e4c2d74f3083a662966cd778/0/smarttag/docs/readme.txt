-----------------------
Package: SmartTag
-----------------------
Author: goldsky <goldsky@virtudraft.com>
        http://twitter.com/_goldsky
Collab: Adam Wintle <adam@monogon.co>
        https://twitter.com/adamwintle

SmartTag is a tagging system for MODX Revolution.
SmartTag is intended to replace MODX's original auto-tag TV.
By having its own tables, SmartTag can be managed easier.