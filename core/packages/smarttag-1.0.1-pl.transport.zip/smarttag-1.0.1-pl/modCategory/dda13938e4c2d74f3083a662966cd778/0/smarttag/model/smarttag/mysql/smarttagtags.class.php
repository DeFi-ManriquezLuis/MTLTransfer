<?php
require_once (dirname(dirname(__FILE__)) . '/smarttagtags.class.php');
class smarttagTags_mysql extends smarttagTags {}