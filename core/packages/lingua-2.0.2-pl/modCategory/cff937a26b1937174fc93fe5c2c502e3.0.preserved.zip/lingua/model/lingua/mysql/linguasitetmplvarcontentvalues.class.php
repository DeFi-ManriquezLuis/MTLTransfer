<?php
require_once (dirname(dirname(__FILE__)) . '/linguasitetmplvarcontentvalues.class.php');
class linguaSiteTmplvarContentvalues_mysql extends linguaSiteTmplvarContentvalues {}