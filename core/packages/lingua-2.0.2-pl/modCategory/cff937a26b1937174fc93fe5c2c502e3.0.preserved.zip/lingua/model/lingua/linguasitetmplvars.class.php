<?php
class linguaSiteTmplvars extends xPDOSimpleObject {}