<?php
class linguaLangs extends xPDOSimpleObject {}