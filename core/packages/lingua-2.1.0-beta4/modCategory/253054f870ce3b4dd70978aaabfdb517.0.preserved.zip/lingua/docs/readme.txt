-----------------------
Package: Lingua
-----------------------
goldsky
Concept, System Architecture and Design, Author
goldsky@virtudraft.com
http://www.virtudraft.com
http://twitter.com/_goldsky

Adam Wintle/Monogon Company Limited
Concept and Strategic Development
adam@monogon.co
http://www.monogon.co
https://twitter.com/adamwintle

Lingua is a multi-lingual plugin system for MODX Revolution.

References:
1. http://en.wikipedia.org/wiki/ISO_639-1_language_matrix
2. http://www.science.co.il/language/locale-codes.asp
3. http://www.php.net/manual/en/book.intl.php