<?php
/**
 * migx
 *
 * @package migx
 * @language en
 */


$_lang['mig.tabs'] = 'Form Tabs';
$_lang['mig.columns'] = 'Grid Columns';
$_lang['mig.btntext'] = '"Add Item" Replacement';
$_lang['mig.previewurl'] = 'Preview Url';
$_lang['mig.jsonvarkey'] = 'Preview JsonVarKey';
$_lang['mig.configs'] = 'Configurations';
$_lang['mig.autoResourceFolders'] = 'Auto Resource Folders';