tinyMCE.addI18n('pl.modxlink',{
    link_desc:"Insert/edit link"
});