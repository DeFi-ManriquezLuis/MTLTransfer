tinyMCE.addI18n('uk.modxlink',{
    link_desc:"Insert/edit link"
});