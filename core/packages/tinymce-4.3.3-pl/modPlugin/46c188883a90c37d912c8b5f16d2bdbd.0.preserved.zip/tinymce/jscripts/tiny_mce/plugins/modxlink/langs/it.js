tinyMCE.addI18n('it.modxlink',{
    link_desc:"Insert/edit link"
});