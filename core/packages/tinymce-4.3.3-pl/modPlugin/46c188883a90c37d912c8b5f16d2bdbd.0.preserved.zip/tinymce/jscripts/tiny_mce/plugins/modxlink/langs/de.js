tinyMCE.addI18n('de.modxlink',{
    link_desc:"Link einf\u00FCgen/bearbeiten"
});