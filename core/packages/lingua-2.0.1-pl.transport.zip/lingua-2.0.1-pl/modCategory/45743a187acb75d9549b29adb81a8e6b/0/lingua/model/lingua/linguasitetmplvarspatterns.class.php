<?php
class linguaSiteTmplvarsPatterns extends xPDOSimpleObject {}