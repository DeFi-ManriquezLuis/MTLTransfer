<?php

$_lang['prop_getKey_desc'] = 'Request key';
$_lang['prop_lingua.get_key_desc'] = 'Request key';
$_lang['prop_codeField_desc'] = 'Field name to be used for selector';
$_lang['prop_tplWrapper_desc'] = 'Wrapper template';
$_lang['prop_tplItem_desc'] = 'Item template';
$_lang['prop_sortby_desc'] = 'Sort the list by';
$_lang['prop_sortdir_desc'] = 'Sort direction';
$_lang['prop_phsPrefix_desc'] = 'Additional prefix for templates';