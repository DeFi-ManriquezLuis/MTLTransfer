<?php
require_once (dirname(dirname(__FILE__)) . '/lingualangs.class.php');
class linguaLangs_mysql extends linguaLangs {}