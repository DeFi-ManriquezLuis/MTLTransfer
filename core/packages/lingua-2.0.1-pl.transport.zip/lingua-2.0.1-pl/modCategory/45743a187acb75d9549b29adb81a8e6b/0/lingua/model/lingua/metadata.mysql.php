<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'linguaLangs',
    1 => 'linguaSiteContent',
    2 => 'linguaSiteTmplvarContentvalues',
    3 => 'linguaSiteTmplvars',
    4 => 'linguaSiteTmplvarsPatterns',
  ),
);